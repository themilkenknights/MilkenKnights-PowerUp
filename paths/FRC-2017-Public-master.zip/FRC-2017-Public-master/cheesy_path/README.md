# cheesy-path
Cheesy path is a web app for creating and visualizing autonomous paths before exporting them to the robot.

To run it, open index.html
