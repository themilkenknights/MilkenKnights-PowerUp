package com.team254.cheezdroid.comm;

public interface RobotConnectionStateListener {
    void robotConnected();

    void robotDisconnected();
}
