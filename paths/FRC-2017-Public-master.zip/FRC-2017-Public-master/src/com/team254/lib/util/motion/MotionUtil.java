package com.team254.lib.util.motion;

public class MotionUtil {
    /**
     * A constant for consistent floating-point equality checking within this library.
     */
    public static double kEpsilon = 1e-6;
}
